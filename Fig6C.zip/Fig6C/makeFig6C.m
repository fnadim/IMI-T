%% This is to make Figure 6C. 
clear all;
tvi = dlmread('ramp100.txt');
tvi = downsample(tvi,10);
tmax = tvi(end,1);
%%
tlp = tvi(:,1); 
vlp = tvi(:,2); 
ilp = tvi(:,3);
ibase = mean(ilp(1:10));
iend = mean(ilp(end-10:end));
ilp = ilp - ((iend-ibase) / length(ilp))*ilp;
vmin=-80; vmax=20;

%FUNCTIONS
% Functions:
rampdur=1000;
cycledur = 4.2*rampdur;
ramp = @(t) max(0,t);
slope = (vmax-vmin)/rampdur;
% Periodic ramp-and-hold with each interval = dur;
V = @(t) max(vmin, vmin + ...
    slope*ramp(mod(t,cycledur) -   rampdur) - ...
    slope*ramp(mod(t,cycledur) - 2*rampdur) - ...
    slope*ramp(mod(t,cycledur) - 3*rampdur));
%
% model_params_inf_tau_Fig6C;
model_params_inf_tau_Fig6C;
%
%t0 = 0.7*tmax;
t0=0;
rng = tlp>=t0 & tlp<=tmax;
tlp = tlp(rng);
tlp = tlp-tlp(1);
vlp = vlp(rng);
ilp = sgolayfilt(ilp(rng),3,31);
%% run it:
Y0 = [minfMI1(V(0)) minfMI2(V(0)) hinfMI2(V(0)) 5e-4];
%  Y0 = [minfMI1(V(0)) minfMI2(V(0)) hinfMI2(V(0)) Cainf];
tspan=[0 tmax-t0];
[T, Y] = ode45(dydt, tspan, Y0);
TVY=[T V(T) Y];
m1 = TVY(:,3); m2 = TVY(:,4); h2 = TVY(:,5); Cai = TVY(:,6);
%%
% gMI1=0.1;  gMI2=0.7;
% EMI1=23; EMI2=23;
IMI1 = gMI1 * m1 .*          (V(T) - EMI1);
IMI2 = gMI2 * m2.^3 .* h2 .* (V(T) - EMI2);
IMI3 = 1e3 * PCa * dCa(V(T),m2,hinf3(Cai),Cai);
% imod1 = IMI1+IMI2;
imod1 = IMI1+IMI3;
imod1 = interp1(T,imod1,tlp);
%% plot it with data:
tvivmim = [tlp vlp ilp V(tlp) imod1-imod1(1)];
figure(1);
clf;
% %%%%% Currents:
axx(1)=subplot(3,1,[1 2]);
    plot(tlp/1000, ilp, 'r', 'LineWidth',3);
    hold on;
    plot(tlp/1000, imod1-imod1(1), 'k', 'LineWidth',3); 
    hold off;
    legend('biol','model', 'Location','S');
    ylabel('I (nA)');
    ax=gca; 
    ax.FontSize = 24;
    ax.TickDir = 'out';
    ax.XTickLabel=[];
    ax.Color = 'none'; 
    ax.LineWidth = 2;
    box off;
% %%%%% Voltage:
axx(2)=subplot(313);
    plot(tlp/1000, V(tlp), 'k', 'LineWidth',3); hold off;
    ylim([-90 30]);
    xlabel('time (s)');
    ylabel('V (mV)');
    ax=gca; 
    ax.FontSize = 24;
    ax.TickDir = 'out'; 
    ax.Color = 'none'; 
    ax.LineWidth = 2;
    box off;
