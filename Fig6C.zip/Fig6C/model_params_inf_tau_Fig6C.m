% Model parameters for Fig 6C
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
model_params_inf_tau_Fig6;
gMI1=0.08;
EMI1=0; 
%
hinf3   = @(cai) 1 ./ (1+ (cai/.015).^4);
tauCa = @(cai) 12000; % ms
%
zCa = 2;
NA = 6.022e23; % 1/mol
qe = 1.602e-19; % C
Cao   = 13; % mM
Cainf = 0.020; % uM
kBoltz = 1.381e-23; % J/K
TKelv = 286.15; % K
cov = 1e-3*zCa*qe/(kBoltz*TKelv); 
PCa  = 0.14; % 1/ms
P1 = 31.6; % um3/ms
vol = 6.49; % um3
coCa = P1/(PCa*zCa*qe*NA*vol);
efun = @(x) x ./ (exp(x) - 1);
ghk = @(v,cai,cao) 1e-7*NA*qe*zCa*(cai.*efun(-cov*v) - cao.*efun(cov*v));
dCa = @(v,m,h,cai) m.^3 .*  h .* ghk(v,cai,Cao);
eCa = @(cai) 1e3*(kBoltz*TKelv)/(qe*zCa)*log(Cao./cai);
% IMI-T(Ca) =  PCa * dCa(V(T),m2,hinf3(Cai),Cai);
% %%%%%%% run parameters:
% dy/dt: Here y is [m_MI m_MI2 h_MI2 Cai]
dydt = @(t,y) [(minfMI1(V(t))-y(1)) ./ taumMI1(V(t)); ...
               (minfMI2(V(t))-y(2)) ./ taumMI2(V(t)); ...
               (hinfMI2(V(t))-y(3)) ./ tauhMI2(V(t));
               (1e-3*Cainf-y(4)) ./ tauCa(y(4)) - coCa*dCa(V(t),y(2),hinf3(y(4)),y(4))];

