% Model to estimate IMI and IMI2 levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% max conductances and reverswal potentials IMI + IMI2:
gMI1 = 0.125; EMI1 = 35; % nS, mV 
gMI2 = 1.0;   EMI2 =24;  % nS, mV
% minf, hinf and taus
minfMI1 = @(v) 1 ./ (1+exp(-(v+19)/18));
minfMI2 = @(v) 1 ./ (1+exp(-(v+11.8)/12));

taumMI1 = @(v) 2; % ms
taumMI2 = @(v) 2  + 150 ./ cosh(.25*(v+20)); % ms
hinfMI2 = @(v) 1 ./ (1+exp((v+40)/7));
tauhMI2 = @(v) 100 + 600 ./ cosh(0.1*(v+30))+200./(1+exp(-0.2*(v+30))); % ms

% %%%%%%% run parameters:
% dy/dt: Here y is [m_MI m_MI2 h_MI2 Cai]
dydt = @(t,y) [(minfMI1(V(t))-y(1)) ./ taumMI1(V(t)); ...
               (minfMI2(V(t))-y(2)) ./ taumMI2(V(t)); ...
               (hinfMI2(V(t))-y(3)) ./ tauhMI2(V(t))];

