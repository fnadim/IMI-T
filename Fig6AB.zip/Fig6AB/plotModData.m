function axx = plotModData(tvivmodimod,fig)
figure(fig);
clf;
sz = min(size(tvivmodimod));
% %%%%% Currents:
axx(1)=subplot(3,1,[1 2]);
plot(tvivmodimod(:,1),tvivmodimod(:,3), 'r', 'LineWidth',1.5);
if sz > 3
    hold on;
    plot(tvivmodimod(:,1),tvivmodimod(:,5), 'k', 'LineWidth',1.5); 
    hold off;
end
set(gca,'XTickLabel',[]);
grid on;
% %%%%% Voltage:
axx(2)=subplot(313);
plot(tvivmodimod(:,1), tvivmodimod(:,2), 'r', 'LineWidth', 2); 
if sz > 3
    hold on;
    plot(tvivmodimod(:,1), tvivmodimod(:,4), 'k', 'LineWidth',1.5); hold off;
    hold off;
end
vmin=min(tvivmodimod(:,2)); vmax=max(tvivmodimod(:,2));
ylim([vmin-10 vmax+10]);
xlabel('t (ms)');
ylabel('V (mV)');
if sz > 3
    legend('biol','model', 'Location','S');
end    
linkaxes(axx,'x')
