clearvars;
close all;
file = '148_015_RHandWave.txt';
fign=0; base=-80; scale=2.;
%% Figure 6Biii: REALISTIC WAVEFORMS scaled to go from -80 to +20 mV
filt = true;
col = 8; t0 = 8000; tmax = 16000; fign = fign+1;
[ax{fign}, tvi{fign}] = Simulate_only(file, col, t0, tmax, filt, scale, base, fign); 
%
col = 10; t0 = 3000; tmax = 7000; fign = fign+1;
[ax{fign}, tvi{fign}] = Simulate_only(file, col, t0, tmax, filt, scale, base, fign); 
%
col = 12; t0 = 3750; tmax = 6750; fign = fign+1;
[ax{fign}, tvi{fign}] = Simulate_only(file, col, t0, tmax, filt, scale, base, fign); 
%
col = 14; t0 = 3000; tmax = 5000; filt = true; fign = fign+1;
[ax{fign}, tvi{fign}] = Simulate_only(file, col, t0, tmax, filt, scale, base, fign); 
%
col = 16; t0 = 1030; tmax = 2030; filt = true; fign = fign+1;
[ax{fign}, tvi{fign}] = Simulate_only(file, col, t0, tmax, filt, scale, base, fign); 
%
linkaxes([ax{1}(1),ax{2}(1),ax{3}(1),ax{4}(1),ax{5}(1)], 'y')

