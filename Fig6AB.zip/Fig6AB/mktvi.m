function tvi = mktvi(filename, colv)

dat = dlmread(filename,'\t',1,0);
twfm = dat(:,1);
vwfm = dat(:,colv);
iwfm = dat(:, colv+1);
%
range = (vwfm ~= 0);
vwfm = vwfm(range);
iwfm = iwfm(range);
twfm = twfm(range);

%
vf = sgolayfilt(vwfm,3,51);
dv=diff(vf);
idx=find(abs(dv)>=.05);
range=idx(1):idx(end);
%
twfm = twfm(range);
vwfm = vwfm(range);
iwfm = iwfm(range);
tvi = [(twfm-twfm(1))*1000 vwfm iwfm];

