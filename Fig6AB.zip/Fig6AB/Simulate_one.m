function [axx tvivmim] = Simulate_one(file, col, t0, tmax, filt, fig)
% Read a data file
tvi = mktvi(file,col);
%%
ds = 5;    % downsample rate

tlp = tvi(:,1); 
len = length(tlp);
if(tmax<=0 | tmax<=t0) 
    tmax = tlp(end); 
end
range = find(tlp>=t0 & tlp <=tmax);
tvi = tvi(range,:);
tlp = tvi(:,1); tlp = tlp - tlp(1);
vlp = tvi(:,2); 
ilp = tvi(:,3);
ibase = mean(ilp(1:5));

if(filt)
    window = 2*ceil(len/400)+1; % filtering window
    vlpf = sgolayfilt(vlp,3,window);
else 
    vlpf = vlp;
end
t2 = downsample(tlp,ds);
v2 = downsample(vlpf,ds);
% v2 = -80 + 2*(v2-min(v2)); % double the v amplitude and start at -80 mV
% Functions:
V = @(t) interp1(t2,v2,t);
%% define it
% %%%%%%% model parameters:
model_params_inf_tau;
%% run it:
Y0 = [minf_MI(V(0)) minf_MI2(V(0)) hinf_MI2(V(0))];
tspan=[0 tmax-t0];
[T, Y] = ode45(dydt, tspan, Y0);
TVY=[T V(T) Y];
m1 = TVY(:,3); m2 = TVY(:,4); h2 = TVY(:,5);
% % pars4IMIs=[gMI mpow_MI EMI gMI2 mpow_MI2 EMI2]; 
IMI  = pars4IMIs(1) * m1.^pars4IMIs(2)  .*      (V(T) - pars4IMIs(3));
IMI2 = pars4IMIs(4) * m2.^pars4IMIs(5) .* h2 .* (V(T) - pars4IMIs(6));
imod = IMI+IMI2;
imod = interp1(T,imod,tlp);
tvivmim = [tlp+t0 vlpf ilp-ibase V(tlp) imod-imod(1)];
% %% plot it with data:
axx = plotModData(tvivmim,fig);
