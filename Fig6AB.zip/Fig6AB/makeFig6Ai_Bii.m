clearvars
close all;
file = './148_015_RHandWave.txt';
%% Figure 6Ai: ramp and hold 
% Simluate_one: file, colv, t0, tmax, filterit, fig);
% set tmax to 0 or -1 to do the whole range
% filt is setting the lowpass filter to true or false
%%% RAMPS:
filt = false; 
%
col = 2; t0 = 9000; tmax = 17500; fig = 1;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
col = 4; t0 = 4200; tmax = 8500; fig = 2;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
col = 6; t0 = 1100; tmax = 3300; fig = 3; 
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
linkaxes([ax{1}(1),ax{2}(1),ax{3}(1)], 'y')
%% Figure 6Bii: REALISTIC WAVEFORMS from -60 to -20 mV
filt = true;
col = 8; t0 = 8000; tmax = 16000; fig = 4;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
col = 10; t0 = 3000; tmax = 7000; fig = 5;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
col = 12; t0 = 3750; tmax = 6750; fig = 6;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
col = 14; t0 = 3000; tmax = 5000; filt = true; fig = 7;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
col = 16; t0 = 1030; tmax = 2030; filt = true; fig = 8;
[ax{fig}, tvivmim{fig}] = Simulate_one(file, col, t0, tmax, filt, fig); 
%
linkaxes([ax{4}(1),ax{5}(1),ax{6}(1),ax{7}(1),ax{8}(1)], 'y')

