% Model to estimate IMI and IMI2 levels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%% model parameters:
mpow_MI = 1; mpow_MI2 = 3; 
pMI  = [0.125   35  -19   18];
pMI2 = [1.   24  -11.8    12];
 
p3 = [2 150 0.25 20 40 7 100 600 0.1 30 200 0.2];

gMI = pMI(1); EMI = pMI(2); vhalfMI = pMI(3); vslopeMI = pMI(4); 
gMI2 = pMI2(1); EMI2 = pMI2(2); vhalfMI2 = pMI2(3); vslopeMI2 = pMI2(4);

% This gets passed to the plotting function:
pars4IMIs = [gMI mpow_MI EMI gMI2 mpow_MI2 EMI2]; 

% minf, hinf and taus
minf_MI = @(v) 1 ./ (1+exp(-(v-vhalfMI)/vslopeMI));
taum_MI = @(v) p3(1); 
minf_MI2 = @(v) 1 ./ (1+exp(-(v-vhalfMI2)/vslopeMI2));
taum_MI2 = @(v) taum_MI(v)  + p3(2) ./ cosh(p3(3)*(v+p3(4)));
hinf_MI2 = @(v) 1 ./ (1+exp((v+p3(5))/p3(6)));
tauh_MI2 = @(v) p3(7) + p3(8) ./ cosh(p3(9)*(v+p3(10)))+p3(11)./(1+exp(-p3(12)*(v+p3(10)))); 

% dy/dt: Here y is [m_MI m_MI2 h_MI2]
dydt = @(t,y) [(minf_MI(V(t)) -y(1)) ./ taum_MI(V(t)); ...
               (minf_MI2(V(t))-y(2)) ./ taum_MI2(V(t)); ...
               (hinf_MI2(V(t))-y(3)) ./ tauh_MI2(V(t))];

